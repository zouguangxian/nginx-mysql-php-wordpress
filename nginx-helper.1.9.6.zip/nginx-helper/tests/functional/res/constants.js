/*
@author : Prabuddha Chakraborty
This is a standalone scripts for centralized management of all constants like Admin Username and Password.
*/

module.exports ={
  //username and password for wordpress Admin Role
    TESTADMINUSERNAME: 'ADMINUSER',
    TESTADMINPASSWORD: 'ADMINPASS',
  //Home site url enter here
   URLS: {
          LOGIN: 'http://wp.localtest.me/'
   }

};
